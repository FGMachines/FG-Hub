from __future__ import annotations
from datetime import datetime, timezone
import hashlib, hmac, json, os, secrets
from typing import Annotated
from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from .database import Base, SessionLocal, engine
from .models import Account, ActivityLog, ApiCredential, DeviceBinding, StripRecord

app = FastAPI(title="FG Link Server", version="0.4.0")
def utcnow(): return datetime.now(timezone.utc)
def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
Db=Annotated[Session,Depends(get_db)]
@app.on_event("startup")
def create_schema(): Base.metadata.create_all(bind=engine)
def _pepper():
    v=os.getenv("FG_LINK_TOKEN_PEPPER","").strip()
    if not v: raise RuntimeError("FG_LINK_TOKEN_PEPPER is required")
    return v.encode()
def _digest(ns,v): return hmac.new(_pepper(),f"{ns}:{v}".encode(),hashlib.sha256).hexdigest()
def _token_hash(v): return _digest("api-token",v)
def _device_hash(v): return _digest("device",v)
def _strip_hash(v): return _digest("strip",v)
def _new_api_token(): return "fgk_"+secrets.token_urlsafe(32)
def _log(db,event_type,account_id=None,detail=None):
    db.add(ActivityLog(account_id=account_id,event_type=event_type,detail_json=json.dumps(detail or {},ensure_ascii=False,separators=(",",":"))))
def _panel_guard(x_fg_panel_token: Annotated[str|None,Header()]=None):
    exp=os.getenv("FG_LINK_PANEL_TOKEN","")
    if not exp or not x_fg_panel_token or not hmac.compare_digest(exp,x_fg_panel_token):
        raise HTTPException(status_code=403,detail="Panel access denied")
def _account_from_bearer(db,authorization):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(status_code=401,detail="Missing API token")
    raw=authorization[7:].strip()
    cred=db.scalar(select(ApiCredential).where(ApiCredential.token_hash==_token_hash(raw),ApiCredential.revoked_at.is_(None)))
    if cred is None: raise HTTPException(status_code=401,detail="Invalid API token")
    account=db.get(Account,cred.account_id)
    if account is None or not account.active: raise HTTPException(status_code=403,detail="Account disabled")
    cred.last_used_at=utcnow()
    return account
class AccountCreate(BaseModel): display_name:str=Field(min_length=2,max_length=160)
class AccountStateChange(BaseModel): active:bool
class BindRequest(BaseModel): device_fingerprint:str=Field(min_length=16,max_length=512)
class HeartbeatRequest(BaseModel): device_fingerprint:str=Field(min_length=16,max_length=512)
class StripInput(BaseModel):
    client_ref:str=Field(min_length=8,max_length=256); display_name:str=Field(min_length=1,max_length=120); online:bool=False
class StripSyncRequest(BaseModel):
    device_fingerprint:str=Field(min_length=16,max_length=512); strips:list[StripInput]=Field(default_factory=list,max_length=64)
def _account_view(account):
    binding=account.device_binding; now=utcnow(); win=int(os.getenv("FG_LINK_CONTROLLER_ONLINE_SECONDS","90"))
    last=binding.last_seen_at if binding else None
    if last and last.tzinfo is None: last=last.replace(tzinfo=timezone.utc)
    online=bool(last and (now-last).total_seconds()<=win)
    return {"id":account.id,"display_name":account.display_name,"active":account.active,"created_at":account.created_at.isoformat(),
            "device_bound":binding is not None and binding.active,"device_online":online,"last_seen_at":last.isoformat() if last else None,
            "strip_count":len(account.strips),"online_strip_count":sum(1 for i in account.strips if i.online)}
@app.get("/healthz")
def healthz(): return {"service":"FG Link Server","status":"ok","time":utcnow().isoformat(),"mode":"relay-ready"}
@app.get("/api/v1/server/status")
def server_status(): return {"service":"FG Link Server","cloud_enabled":True,"direct_mttl_access":False,"stores_wifi_credentials":False,
"stores_zerotier_secrets":False,"panel_power_control":False,"device_account_policy":"one-device-one-account",
"controller_online_window_seconds":int(os.getenv("FG_LINK_CONTROLLER_ONLINE_SECONDS","90"))}
@app.post("/api/v1/client/bind")
def client_bind(body:BindRequest,db:Db,authorization:Annotated[str|None,Header()]=None):
    account=_account_from_bearer(db,authorization); fh=_device_hash(body.device_fingerprint)
    ex=db.scalar(select(DeviceBinding).where(DeviceBinding.account_id==account.id))
    if ex:
        if not hmac.compare_digest(ex.device_fingerprint_hash,fh): raise HTTPException(status_code=409,detail="This account is already bound to another phone")
        ex.active=True; ex.last_seen_at=utcnow(); _log(db,"device.rebind",account_id=account.id); db.commit(); return {"status":"bound","account":_account_view(account)}
    other=db.scalar(select(DeviceBinding).where(DeviceBinding.device_fingerprint_hash==fh))
    if other and other.account_id!=account.id: raise HTTPException(status_code=409,detail="This phone is already bound to another account")
    db.add(DeviceBinding(account_id=account.id,device_fingerprint_hash=fh,active=True,last_seen_at=utcnow())); _log(db,"device.bind",account_id=account.id)
    try: db.commit()
    except IntegrityError:
        db.rollback(); raise HTTPException(status_code=409,detail="One phone can own only one FG Link account")
    db.refresh(account); return {"status":"bound","account":_account_view(account)}
@app.post("/api/v1/client/heartbeat")
def client_heartbeat(body:HeartbeatRequest,db:Db,authorization:Annotated[str|None,Header()]=None):
    a=_account_from_bearer(db,authorization); b=a.device_binding
    if b is None or not b.active: raise HTTPException(status_code=409,detail="Phone is not bound")
    if not hmac.compare_digest(b.device_fingerprint_hash,_device_hash(body.device_fingerprint)): raise HTTPException(status_code=409,detail="Phone binding mismatch")
    b.last_seen_at=utcnow(); db.commit(); return {"status":"ok","account_id":a.id,"active":a.active}
@app.post("/api/v1/client/strips/sync")
def sync_strips(body:StripSyncRequest,db:Db,authorization:Annotated[str|None,Header()]=None):
    a=_account_from_bearer(db,authorization); b=a.device_binding; fh=_device_hash(body.device_fingerprint)
    if b is None or not b.active or not hmac.compare_digest(b.device_fingerprint_hash,fh): raise HTTPException(status_code=409,detail="Phone binding mismatch")
    b.last_seen_at=utcnow(); seen=set()
    for item in body.strips:
        rh=_strip_hash(item.client_ref); seen.add(rh)
        rec=db.scalar(select(StripRecord).where(StripRecord.account_id==a.id,StripRecord.client_ref_hash==rh))
        if rec is None: rec=StripRecord(account_id=a.id,client_ref_hash=rh,display_name=item.display_name); db.add(rec)
        rec.display_name=item.display_name; rec.online=item.online; rec.last_seen_at=utcnow()
    for rec in a.strips:
        if rec.client_ref_hash not in seen: rec.online=False
    _log(db,"strips.sync",account_id=a.id,detail={"count":len(body.strips)}); db.commit(); return {"status":"ok","count":len(body.strips)}
@app.get("/panel",response_class=HTMLResponse,dependencies=[Depends(_panel_guard)])
def panel(): return PANEL_HTML
@app.get("/panel/api/accounts",dependencies=[Depends(_panel_guard)])
def panel_accounts(db:Db):
    a=db.scalars(select(Account).order_by(Account.created_at.desc())).unique().all(); return {"accounts":[_account_view(x) for x in a]}
@app.post("/panel/api/accounts",dependencies=[Depends(_panel_guard)])
def panel_create_account(body:AccountCreate,db:Db):
    a=Account(display_name=body.display_name.strip()); db.add(a); db.flush(); raw=_new_api_token()
    db.add(ApiCredential(account_id=a.id,token_hash=_token_hash(raw),token_hint=raw[-6:])); _log(db,"account.create",account_id=a.id,detail={"display_name":a.display_name})
    db.commit(); db.refresh(a); return {"account":_account_view(a),"api_token":raw}
@app.post("/panel/api/accounts/{account_id}/rotate-token",dependencies=[Depends(_panel_guard)])
def rotate(account_id:str,db:Db):
    a=db.get(Account,account_id)
    if a is None: raise HTTPException(status_code=404,detail="Account not found")
    now=utcnow()
    for c in db.scalars(select(ApiCredential).where(ApiCredential.account_id==account_id,ApiCredential.revoked_at.is_(None))).all(): c.revoked_at=now
    raw=_new_api_token(); db.add(ApiCredential(account_id=account_id,token_hash=_token_hash(raw),token_hint=raw[-6:])); _log(db,"api.rotate",account_id=account_id); db.commit()
    return {"api_token":raw}
@app.post("/panel/api/accounts/{account_id}/state",dependencies=[Depends(_panel_guard)])
def state(account_id:str,body:AccountStateChange,db:Db):
    a=db.get(Account,account_id)
    if a is None: raise HTTPException(status_code=404,detail="Account not found")
    a.active=body.active; _log(db,"account.state",account_id=account_id,detail={"active":body.active}); db.commit(); return {"account":_account_view(a)}
@app.post("/panel/api/accounts/{account_id}/unbind",dependencies=[Depends(_panel_guard)])
def unbind(account_id:str,db:Db):
    a=db.get(Account,account_id)
    if a is None: raise HTTPException(status_code=404,detail="Account not found")
    if a.device_binding is not None: db.delete(a.device_binding); _log(db,"device.unbind",account_id=account_id); db.commit()
    return {"status":"unbound"}
@app.get("/panel/api/accounts/{account_id}/strips",dependencies=[Depends(_panel_guard)])
def strips(account_id:str,db:Db):
    a=db.get(Account,account_id)
    if a is None: raise HTTPException(status_code=404,detail="Account not found")
    return {"strips":[{"id":i.id,"display_name":i.display_name,"online":i.online,"last_seen_at":i.last_seen_at.isoformat() if i.last_seen_at else None} for i in a.strips]}
@app.get("/panel/api/activity",dependencies=[Depends(_panel_guard)])
def activity(db:Db,limit:int=100):
    limit=max(1,min(limit,300)); rows=db.scalars(select(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(limit)).all()
    return {"events":[{"id":r.id,"account_id":r.account_id,"event_type":r.event_type,"detail":json.loads(r.detail_json or "{}"),"created_at":r.created_at.isoformat()} for r in rows]}
from pathlib import Path
PANEL_HTML=(Path(__file__).with_name("panel.html")).read_text(encoding="utf-8")
