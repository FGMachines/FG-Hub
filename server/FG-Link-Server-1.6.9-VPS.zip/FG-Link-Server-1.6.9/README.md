# FG Link Private Server

Private backend for the optional FG Link relay and administration panel.

## Current capabilities

- One phone = one account, enforced at database level.
- One account = one active phone binding.
- Admin-created customer accounts.
- High-entropy API token generation and rotation; only HMAC hashes are stored.
- Admin-only phone transfer/unbind.
- Controller heartbeat and online/offline status.
- Pseudonymous strip inventory/status sync; raw local strip references are not stored.
- Activity log.
- Dark FG Machines web panel under `/panel`.
- PostgreSQL, FastAPI, Caddy HTTPS, Docker Compose.
- No Wi-Fi passwords, ZeroTier secrets, Android private keys, or direct MTTL relay-control secrets on the VPS.

## Deployment

Target: Ubuntu 24.04 or Debian 12.

1. Point a DNS A/AAAA record to the VPS.
2. Copy this folder to the VPS.
3. Run:

```bash
sudo bash install-vps.sh
```

Panel:

```text
https://YOUR_DOMAIN/panel
```

Health check:

```text
https://YOUR_DOMAIN/healthz
```
